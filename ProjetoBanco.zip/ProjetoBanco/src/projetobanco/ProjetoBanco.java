package projetobanco;


public class ProjetoBanco {

    public static void main(String[] args) {
        Conta c1 = new ContaPoupanca();
        Conta c2 = new ContaPagamentos();
        
        c1.nomeTitular = "Luís";
        c1.numConta = 1;
        
        c2.nomeTitular = "Gabriel";
        c2.numConta = 2;
        
        
        
        
        
        System.out.println(c2.nomeTitular);
        System.out.println(c1.getSaldo());
        
        c1.depositar(50);
        c2.depositar(50);
        System.out.println("Saldo C1"+c1.getSaldo());
        System.out.println("Saldo C2 "+c2.getSaldo());
        
        c1.sacar(20);
        c2.sacar(20);
        System.out.println("Saldo C1 após saque "+c1.getSaldo());
        System.out.println("Saldo C2 após saque "+c2.getSaldo());
        
        if(c1.transferir(c2, 20)==true){
            System.out.println("Transferência realizada com sucesso.");
        }else
            System.out.println("Transferência não realizada - sem saldo.");
        
        System.out.println("Saldo do C1 após transferência "+c1.getSaldo());
        System.out.println("Saldo do C2 após transferência "+c2.getSaldo());
        
        
        
    }
    
}

class Conta {
    public String nomeTitular;
    public int numConta;
    private double saldo;
    protected double taxaSaque=1.0;
    
    
    public boolean depositar(double valor){
        
        this.saldo = this.saldo+ valor;
        return true;
    }
    
    public boolean sacar(double valor){
        
        if (valor+this.taxaSaque<=this.saldo){
            this.saldo = this.saldo - valor - this.taxaSaque;
            return true;
        }else
            return false;
    }
    
    public double getSaldo(){
        return this.saldo;
    }
    
    public boolean transferir(Conta contaDestino, double valor){
        
        if(this.sacar(valor)==true){
            contaDestino.depositar(valor);
            return true;
        }else
            return false;
        
    }
}

class ContaPagamentos extends Conta{
    
    public boolean sacar(double valor){
        
        super.taxaSaque=2.0;
        return super.sacar(valor);
        
    }
}

class ContaPoupanca extends Conta{
    
    public boolean sacar(double valor){
        
        super.taxaSaque=0.50;
        return super.sacar(valor);
        
    }
    
}